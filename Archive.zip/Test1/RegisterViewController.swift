//
//  RegisterViewController.swift
//  Test1
//
//  Created by apple on 19/08/19.
//  Copyright © 2019 DBS. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet weak var myButton2: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myButton2.layer.cornerRadius = myButton2.frame.size.height/2
        myButton2.layer.masksToBounds = true
        
        myButton2.setGradientBackground(colorOne: UIColor.red, colorTwo: UIColor.black)


    }
    

    

}
