//
//  LoginViewController.swift
//  Test1
//
//  Created by apple on 19/08/19.
//  Copyright © 2019 DBS. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var myButton1: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        myButton1.layer.cornerRadius = myButton1.frame.size.height/2
        myButton1.layer.masksToBounds = true
        
        myButton1.setGradientBackground(colorOne: UIColor.red, colorTwo: UIColor.black)


        
    }

}
